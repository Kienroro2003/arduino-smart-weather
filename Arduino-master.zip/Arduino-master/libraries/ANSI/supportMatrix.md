
# Support Matrix

- To be updated when time permits.
- name might change


| function      | TeraTerm | puTTY |  miniCom  |
|:--------------|:--------:|:-----:|:---------:|
| normal        |     Y    |   Y   |           |
| bold          |     Y    |   Y   |           |
| low           |     Y    |   Y   |           |
| underline     |     Y    |   Y   |           |
| blink         |     Y    |   Y   |           |
| blinkFast     |     -    |   -   |           |
| reverse       |     Y    |   Y   |           |
| clearScreen   |     Y    |   Y   |           |
| clearLine     |     Y    |   Y   |           |
| home          |     Y    |   Y   |           |
| gotoXY        |     Y    |   Y   |           |
| cursorUp      |     Y    |   Y   |           |
| cursorDown    |     Y    |   Y   |           |
| cursorForward |     Y    |   Y   |           |
| cursorBack    |     Y    |   Y   |           |
|               |          |       |           |
|               |          |       |           |
|               |          |       |           |

Feel free to add a PR to update the table above.
